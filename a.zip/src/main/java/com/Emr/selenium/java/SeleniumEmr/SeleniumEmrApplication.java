package com.Emr.selenium.java.SeleniumEmr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SeleniumEmrApplication {

	public static void main(String[] args) {
		SpringApplication.run(SeleniumEmrApplication.class, args);
	}

}
