package com.Emr.selenium.java.SeleniumEmr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeleniumEmrApplicationTests {

	@Test
	void contextLoads() {
	}

}
